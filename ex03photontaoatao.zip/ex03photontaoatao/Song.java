/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03photontaoatao;

/**
 *
 * @author julia
 */
public class Song {
    String title, album;
    int date; 
    
    public Song(String title, String album, int date){
        this.title = title;
        this.album = album;
        this.date = date;
    }

}
